import java.util.*;

/**
 * Write a description of class Key here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Key
{
    private String clave;
    private HashMap<String,Integer> map = new HashMap<String,Integer>();

    public Key(String k1, String k2) {
        clave = k1+k2;
        map.put(clave,clave.hashCode());
    }
    
    public int hashCode() {
        return clave.hashCode();
    }
    
    public int getValor(String k1, String k2){
        return map.get(k1+k2);
    }
    
    public static <K, V> K getKey(Map<K, V> map, V value)
    {
        for (Map.Entry<K, V> entry: map.entrySet())
        {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }
}
