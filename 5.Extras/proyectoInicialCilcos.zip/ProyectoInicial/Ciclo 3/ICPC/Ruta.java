/**
 * Write a description of class Ruta here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ruta {
    // instance variables - replace the example below with your own
    private Rectangle ruta;

    /**
     * Constructor for objects of class Ruta
     */
    public Ruta() {
        this.ruta = new Rectangle();
      
    }
    
    /**
     * set the route
     * @param interseccion A route starting point
     * @param interseccion B route end point
     */
    public Ruta setRoute(Ruta route,Interseccion interseccionA, Interseccion interseccionB){
        int posAx = interseccionA.getPositionx();
        int posAy = interseccionA.getPositiony();
        int posBx = interseccionB.getPositionx();
        int posBy = interseccionB.getPositiony();
        int numerador = posBy-posAy;
        int denominador = posBx-posAx;
        int distancia = getDistance(denominador,numerador);
        int angulo = getAngle(posAx,posAy,posBx,posBy);
        int mayorX = posAx > posBx ? posBx : posAx;
        int mayorY = 0;
        if(posAx == posBx && posAy > posBy){
            mayorY = posAy;
        }
        if(posAx == posBx && posAy < posBy){
            mayorY = posBy;
        }
        else{
            mayorY = mayorX == posAx ? posAy : posBy;
        }
        route.changePosition((mayorX + 15), (mayorY - 22));
        route.changeSize(10,distancia);
        route.changeAngle(angulo);
        return route;
    }
    
    /*
     * Get the distance between two points
     * @param point1
     * @param point2
     * @return distance
     */
    private int getDistance(int point1, int point2){
        int distance;
        distance = (int)(Math.sqrt(Math.pow((point1),2) + Math.pow((point2),2)));
        return distance;
    }
    
    /*
     * Get the slope between two points
     * @param posAx 
     * @param posAy
     * @param posBx
     * @param posBy
     * @return slope
     */
    private double getSlope(int posAx,int posAy , int posBx, int posBy){
        double numerador;
        double denominador;
        double pendiente;
        numerador = (posBy - posAy);
        denominador =(posBx - posAx);
        pendiente = numerador / denominador;
        return pendiente * -1;
    }
    
    /*
     * Get the Angle between two points
     * @param 
     * @param 
     * @param posAx position of an intersectionA in x
     * @param posbx position of an intersectionB in x
     * @return angle
     */
    private int getAngle(int posAx,int posAy, int posBx, int posBy){
        int angle;
        double pendiente = getSlope(posAx,posAy,posBx,posBy);
        if((posBx - posAx)== 0 ){
            angle = posAx < posBx ? 270 : 90;
        }
        else{
        angle = (int)(Math.toDegrees(Math.atan(pendiente)));
        }
        return angle;
    }
    
    public void makeVisible(){
        this.ruta.makeVisible();
    }
    
    public void makeInvisible(){
        this.ruta.makeInvisible();
    }
    
    public void changeAngle(int newAngle) {
        this.ruta.setAngle(newAngle);
    }
    
    public void changePosition(int newPositionx, int newPositiony){
        this.ruta.setPosition(newPositionx,newPositiony);
    }
    
    public int getAngle() {
        return this.ruta.getAngle();
    }
    
    public int getPositionX(){
        return this.ruta.getPosX();
    }
    
    public int getPositionY(){
        return this.ruta.getPosY();
    }
    
    /**
     * Get color of the rectangle
     */
    public String getColor(){
        return this.ruta.getColor();
    }
    
    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidth must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        this.ruta.changeSize(newHeight, newWidth);
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        this.ruta.changeColor(newColor);
    }
}
