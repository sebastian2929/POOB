
/**
 * Write a description of class Interseccion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Interseccion
{
    // instance variables - replace the example below with your own
    private Circle interseccion;
    
    /**
     * Constructor for objects of class Interseccion
     * @param color Color of the intersection
     * @param x position x of the intersection
     * @param y position y of the intersection
     */
    public Interseccion(String color, int x , int y) {
        this.interseccion = new Circle();
        this.interseccion.changeColor(color);
        this.interseccion.moveHorizontal(x*10);
        this.interseccion.moveVertical(y*10);
    }
    
    public void makeVisible(){
        this.interseccion.makeVisible();
    }
    
    public void makeInvisible(){
        this.interseccion.makeInvisible();
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        this.interseccion.changeColor(newColor);
    }
    
    /**
     * Move the intersection horizontally.
     * @param distance the desired distance in pixels
     */
    public void moveHorizontal(int distance){
        this.interseccion.moveHorizontal(distance);
    }

    /**
     * Move the intersection vertically.
     * @param distance the desired distance in pixels
     */
    public void moveVertical(int distance){
        this.interseccion.moveVertical(distance);
    }
    
    /**
     * Get the color of the intersection
     */
    public String getColor(){
        return this.interseccion.getColor();
    }
    
    /**
    *Get the xPosition of the intersction
    */
    public int getPositionx(){
        return this.interseccion.getPositionx();
    }
    
    /**
    *Get the yPosition of the intersection
    */
    public int getPositiony(){
        return this.interseccion.getPositiony();
    }
}
