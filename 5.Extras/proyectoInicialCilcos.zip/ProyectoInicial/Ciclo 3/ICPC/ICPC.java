import java.util.*;

/**
 * Crea un red ICPC donde se pueden agregar y modificar intercepciones, rutas y sennales.
 * 
 * @Andres Felipe Arias Ajiaco y Sebastian David Blanco Rodriguez. 
 * @version 1.3.
 */


public class ICPC {
    private ArrayList<Interseccion> intersections = new ArrayList<Interseccion>();
    private ArrayList<String> colorIntersections = new ArrayList<String>();   //Se puede quitar
    private ArrayList<Ruta> routes = new ArrayList<Ruta>();
    private HashMap<Ruta,Sennal> signs  = new HashMap<Ruta,Sennal>();
    private HashMap<Integer,Ruta> map = new HashMap<Integer,Ruta>();
    private HashMap<String,ArrayList<Ruta>> mapRoutesStr = new HashMap<String,ArrayList<Ruta>>();
    private HashMap<String,ArrayList<String>> routeStr = new HashMap<String,ArrayList<String>>();
    private int length;
    private int width;
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    private boolean ok;
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int length, int width) {
        this.ok = false;
        Canvas board = Canvas.getCanvas("ICPC",width,length);
        board.redraw1();
        this.ok = true;
    }
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int length, int width, int cost) {
        
       
    }
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int cost, int[][] routesSpeedLimits) {
        
       
    }
    
    /**
     * Metodo que annade una interseccion a la red ICPC.
     * @param color Cadena con el color de la inteseccion.
     * @param x Entero con la posicion en x de la interseccion.
     * @param y Entero con la posicion en y de la interseccion.
     */
    public void addInteserction(String color, int x, int y) {
        this.ok = false;
        Interseccion intersection = new Interseccion(color, x, y);
        if (this.isVisible) {
            intersection.makeVisible();
        }
        intersections.add(intersection);
        colorIntersections.add(color);
        mapRoutesStr.put(color,new ArrayList<Ruta>());
        this.ok = true;
    }
    
    /**
     * Metodo que annade una ruta a la red ICPC.
     * @param intersectionA Color con la interseccion A.
     * @param intersectionB Color con la interseccion B.
     */
    public void addRoute(String intersectionA, String intersectionB) {
        this.ok = false;
        if(colorIntersections.contains(intersectionA) && colorIntersections.contains(intersectionB)){
            verificar(intersectionA,intersectionB);
            Interseccion interseccionA = getIntersection(intersectionA);
            Interseccion interseccionB = getIntersection(intersectionB);
            Ruta ruta = new Ruta();
            ruta.setRoute(ruta,interseccionA,interseccionB);
            Key clave = new Key(intersectionA,intersectionB);
            map.put(clave.hashCode(),ruta);
            ArrayList RutasA = mapRoutesStr.get(intersectionA);
            ArrayList RutasB = mapRoutesStr.get(intersectionB);
            RutasA.add(ruta);
            RutasB.add(ruta);
            routes.add(ruta);
            if (this.isVisible) {
            ruta.makeVisible();
            this.ok = true;
            }
            else{
                System.out.println("No es posible");
            }
        }
        else{
            System.out.println("No es posible");
        }
    }
    
    /**
     * Metodo que annade una sennal a una ruta existente
     * @param intersectionA Color de la interseccionA
     * @param intersectionB Color de la interseccionB
     * @param speedLimit Limite de velocidad
     */
    public void putSign(String intersectionA, String intersectionB, int SpeedLimit){
        this.ok = false;
        if(colorIntersections.contains(intersectionA) && colorIntersections.contains(intersectionB)){
            Interseccion interseccionA = getIntersection(intersectionA);
            Interseccion interseccionB = getIntersection(intersectionB);
            Key password = new Key(intersectionA,intersectionB);
            Integer llave = password.getValor(intersectionA,intersectionB);
            Ruta ruta = map.get(llave);
            if(ruta == null){
                password = new Key(intersectionB,intersectionA);
                llave = password.getValor(intersectionB,intersectionA);
                ruta = map.get(llave);
            }
            Sennal sennal = new Sennal();
            sennal.setSign(interseccionA,interseccionB,sennal,ruta,SpeedLimit);
            if (this.isVisible) {
            sennal.makeVisible();
            }
            signs.put(ruta,sennal);
            this.ok = true;
        }
        else{
            System.out.println("No es posible");
        }
    }
    
    /***
     * Remove a sign
     * @param IntersectionA Color de la interseccionA
     * @param IntersectionB Color de la interseccionB
     */
    public void removeSign(String intersectionA, String intersectionB){
        if(colorIntersections.contains(intersectionA) && colorIntersections.contains(intersectionB)){
            Key password = new Key(intersectionA,intersectionB);
            Integer llave = password.getValor(intersectionA,intersectionB);
            Ruta ruta = map.get(llave);
            if(ruta == null){
                password = new Key(intersectionB,intersectionA);
                llave = password.getValor(intersectionB,intersectionA);
                ruta = map.get(llave);
            }
            Sennal sennal = signs.get(ruta);
            sennal.makeInvisible();
            signs.remove(ruta);
        }
        else{
            System.out.println("No es posible");
        }
    }
    
    /***
     * Delete a route
     * @param location A
     * @param location B
     */
    public void delRoad(String locationA, String locationB){
        this.ok = false;
        if(colorIntersections.contains(locationA) && colorIntersections.contains(locationB)){
            Key password = new Key(locationA,locationB);
            Integer llave = password.getValor(locationA,locationB);
            Ruta ruta = map.get(llave);
            if(ruta == null){
                password = new Key(locationB,locationA);
                llave = password.getValor(locationB,locationA);
                ruta = map.get(llave);
            }
            ruta.makeInvisible();
            routes.remove(ruta);
            map.remove(llave);
            Sennal sennal = signs.get(ruta);
            if(sennal != null){
                sennal.makeInvisible();
                signs.remove(ruta);
            }
            ArrayList rutasA = mapRoutesStr.get(locationA);
            rutasA.remove(ruta);
            ArrayList rutasB = mapRoutesStr.get(locationB);
            rutasA.remove(ruta);
            verificar(locationA,locationB);
            this.ok = true;
        }
        else{
            System.out.println("No es posible");
        }
    }
    
    /**
     * Metodo que borrra una intercepcion de la red de ICPC.
     * @param color color de la intrecepcion.
     */
    public void delIntersection(String color){
        this.ok = false;
        if(colorIntersections.contains(color)){
            ArrayList<Ruta> rutas = mapRoutesStr.get(color);
            for(Ruta ruta: rutas){
                Sennal sennal = signs.get(ruta);
                if(sennal != null){
                    sennal.makeInvisible();
                    signs.remove(ruta);
                }
                ruta.makeInvisible();
                routes.remove(ruta);
                mapRoutesStr.remove(color);
                Integer clave = getKey(map,ruta);
                map.remove(clave);
                routeStr.remove(color);
            }
            Interseccion interseccion = getIntersection(color);
            interseccion.makeInvisible();
            intersections.remove(interseccion);
            colorIntersections.remove(color);
            this.ok = true;
        }
        else{
            System.out.println("La interseccion no existe");
        }
    }
    
    /***
     * Metodo que perimte consultar las intercepciones.
     */
    public String[] intersections(){
        this.ok = false;
        int cont = 0;
        String[] intercepciones = new String[intersections.size()];
        String color;
        for(int i = 0; i < intersections.size(); i++){
            Interseccion intersec = intersections.get(i);
            if(intersec != null){
                color = intersec.getColor();
                intercepciones[cont] = color;
                cont++;
            }
        }
        this.ok = true;
        return intercepciones;
    }
    
    /**
     * Metodo que permite consultar las rutas
     */
    public String[][] routes(){
        this.ok = false;
        String[][] rutas = new String[routeStr.size()][intersections.size()-1];
        int a = 0;
        for(Map.Entry<String, ArrayList<String>> entry : routeStr.entrySet()) {
            int b = 0;
            for (String s : entry.getValue()) {
                rutas[a][b] = entry.getKey() + "-" + s;
                b++;
            }
            a++;
        }
        this.ok = true;
        return rutas;
    }
    
    /**
     * Metodo que permite consultar las sennales
     */
    public String[][] Signs(){
        this.ok = false;
        String[][] sennal = new String[routeStr.size()][intersections.size()-1];
        int a = 0;
        for(Map.Entry<String, ArrayList<String>> entry : routeStr.entrySet()) {
            int b = 0;
            for (String s : entry.getValue()) {
                sennal[a][b] = entry.getKey() + "-" + s;
                b++;
            }
            a++;
        }
        this.ok = true;
        return sennal;
    }

    /**
     * Finish the program
     */
    public void finish(){
        this.ok = false;
        System.exit(0);
        this.ok = true;
    }
    
    /**
     * Verifica la operacion indicada se pudo ejecutar en el simulador, este devolvera un mensaje de referencia.
     * @return true si la operacion se realizó satisfactoriamente,
     * de lo contrario false.
     */
    public boolean ok() {
        if (this.isVisible) {
            if (!this.ok) {
                System.out.println("La accion no se pudo realizar.");
            }
        }
        return this.ok;
    }
    
    /**
     * Metodo que hace visible la red de ICPC.
     */
    public void makeVisible() {
        this.ok = false;
        this.isVisible = true;
        for (Interseccion intersection : intersections) {
            if (intersection != null) {
                intersection.makeVisible();
            }
        }
        for (Ruta route : routes) {
            if (route != null) {
                route.makeVisible();
            }
        }
        this.ok = true;
    }
    
    /**
     * Metodo que hace invisible la red de ICPC.
     */
    public void makeInvisible() {
        this.ok = false;
        this.isVisible = false;
        for (Interseccion intersection : intersections) {
            if (intersection != null) {
                intersection.makeInvisible();
            }
        }
        for (Ruta route : routes) {
            if (route != null) {
                route.makeVisible();
            }
        }
        this.ok = true;
    }
    
    /*
     * Get the intersection with the color
     * @param intersectionA Color con la interseccion A.
     * @param intersectionB Color con la interseccion B.
     */
    private Interseccion getIntersection(String color){
        this.ok = false;
        Interseccion interseccion = null;
        for (int i=0;i<intersections.size();i++) {
            Interseccion intersec = intersections.get(i);
            if (intersec!= null){
                if (intersec.getColor().equals(color)){
                    interseccion = intersections.get(i);
                }
            }
        }
        this.ok = true;
        return interseccion;
    }
    
    /*
     * 
     */
    private void verificar(String intersectionA,String intersectionB){
        if(routeStr.containsKey(intersectionA)){
            ArrayList lista = routeStr.get(intersectionA);
            lista.add(intersectionB);
        }
        else{
            routeStr.put(intersectionA,new ArrayList<String>());
            ArrayList lista = routeStr.get(intersectionA);
            lista.add(intersectionB);
        }
    }
    
    private static <K, V> K getKey(Map<K, V> map, V value)
    {
        for (Map.Entry<K, V> entry: map.entrySet())
        {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }
}
