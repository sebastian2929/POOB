import javax.swing.JLabel;
/**
 * Write a description of class Sennal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sennal
{
    private Triangle sennal;
    
    /**
     * Constructor for objects of class Ruta
     */
    public Sennal() {
        this.sennal = new Triangle();
    }
    
    /**
     * Ubicate the sign;
     */
    public Sennal setSign(Interseccion interseccionA,Interseccion interseccionB,Sennal sennal,Ruta ruta,int SpeedLimit){
        int posXa = interseccionA.getPositionx();
        int posYa = interseccionA.getPositiony();
        int posXb = interseccionB.getPositionx();
        int posYb = interseccionB.getPositiony();
        int angle = ruta.getAngle();
        int positionX = puntoMediox(posXa,posXb) + 15;
        int positionY = puntoMedioy(posYa,posYb) - 22;
        sennal.changePosition(positionX,positionY);
        return sennal;
    }
    
    public void changePosition(int newPositionx, int newPositiony){
        this.sennal.setPosition(newPositionx,newPositiony);
    }
    
    public void changeAngle(int newAngle) {
        this.sennal.setAngle(newAngle);
    }
    
    private int puntoMediox(int posXa,int posXb){
        int pMx = (posXa + posXb)/2;
        return pMx;
    }
    
    private int puntoMedioy(int posYa,int posYb){
        int pMy = (posYa + posYb)/2;
        return pMy;
    }

    public void makeVisible(){
        this.sennal.makeVisible();
    }
    
    public void makeInvisible(){
        this.sennal.makeInvisible();
    }        
}
