package icpc;
import shapes.*;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

/**
 * Crea un red ICPC donde se pueden agregar y modificar intercepciones, rutas y sennales.
 * 
 * @author Andres Felipe Arias Ajiaco y Sebastian David Blanco Rodriguez.
 * @version
 */
public class ICPC
{
    private HashMap<String,Interseccion> intersecciones = new HashMap <String,Interseccion>();
    private HashMap<String,Ruta> rutas = new HashMap <String,Ruta>();
    private HashMap<String,Sennal> sennales = new HashMap <String,Sennal>();
    private HashMap<String,Integer> speedLimits = new HashMap <String,Integer>();
    private int length;
    private int width;
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    private boolean ok;
    private int cost;

    /**
     * Constructor for objects of class ICPC.
     */
    public ICPC(int length, int width){
        this.ok = false;
        Canvas board = Canvas.getCanvas("ICPC",length,width);
        board.redraw1();
        this.ok = true;
    }

    /**
     * Metodo que annade una interseccion a la red ICPC.
     * @param color Cadena con el color de la inteseccion.
     * @param x Entero con la posicion en x de la interseccion.
     * @param y Entero con la posicion en y de la interseccion.
     */
    public void addIntersection(String color, int x, int y){
        this.ok = false;
        if(!intersecciones.containsKey(color) && !verificarPosInterseccion(x,y)){
            intersecciones.put(color,new Interseccion(color,x,y));
            if (this.isVisible) {
                Interseccion interseccion = intersecciones.get(color);
                interseccion.makeVisible();
                this.ok = true;
            }
            else{
                System.out.println("No es posible");
            }
        }
        else{
            System.out.println("La interseccion no se puede crear");
        }
    }

    /**
     * Metodo que annade una ruta a la red ICPC.
     * @param intersectionA Color con la interseccion A.
     * @param intersectionB Color con la interseccion B.
     */
    public void addRoute(String intersectionA, String intersectionB){
        this.ok = false;
        if(intersectionA != intersectionB && !compararKeyRuta(intersectionA,intersectionB)){
            rutas.put(intersectionA+intersectionB,new Ruta(intersecciones.get(intersectionA),intersecciones.get(intersectionB)));
            if (this.isVisible) {
                Ruta ruta = rutas.get(intersectionA+intersectionB);
                ruta.makeVisible();
                this.ok = true;
            }
            else{
                System.out.println("No es posible"); 
            }
        }
        else{
            System.out.println("Las intersecciones son iguales");
        }
    }

    /**
     * Metodo que annade una sennal a una ruta existente.
     * @param intersectionA Color de la interseccionA.
     * @param intersectionB Color de la interseccionB.
     * @param speedLimit Limite de velocidad.
     */
    public void putSign(String intersectionA, String intersectionB, int SpeedLimit){
        this.ok = false;
        if(intersectionA != intersectionB && compararKeyRuta(intersectionA,intersectionB) && !compararKeySennal(intersectionA,intersectionB)){
            sennales.put(intersectionA+intersectionB,new Sennal(intersecciones.get(intersectionA),intersecciones.get(intersectionB),SpeedLimit));
            speedLimits.put(intersectionA+intersectionB,SpeedLimit);
            if (this.isVisible) {
                Sennal sennal = sennales.get(intersectionA+intersectionB);
                sennal.makeVisible();
                this.ok = true;
            }
            else{
                System.out.println("No es posible"); 
            }
        }
        else{
            System.out.println("La sennal no se puede crear");
        }
    }

    /**
     * Metodo que borra una intercepcion de la red de ICPC.
     * @param color color de la intrecepcion.
     */
    public void delIntersection(String color){
        ArrayList<String> clavesRutas = verificarKeyRuta(color);
        ArrayList<String> clavesSennales = verificarKeySennal(color);
        this.ok = false;
        if(intersecciones.containsKey(color)){
            Interseccion interseccion = intersecciones.get(color);
            interseccion.makeInvisible();
            intersecciones.remove(color);
            for(String clave: clavesRutas){
                if(clave != null){
                    Ruta ruta = rutas.get(clave);
                    ruta.makeInvisible();
                    rutas.remove(clave);
                }
            }
            for(String clave: clavesSennales){
                if(clave != null){
                    Sennal sennal = sennales.get(clave);
                    sennal.makeInvisible();
                    sennales.remove(clave);
                    speedLimits.remove(clave);
                }
            }
            this.ok = true;
        }
        else{
            System.out.println("La interseccion no existe");
        }
    }

    /**
     * Metodo que borra una ruta.
     * @param intersection A Color de la interseccionA.
     * @param intersection B Color de la interseccionB.
     */
    public void delRoad(String intersectionA, String intersectionB){
        this.ok = false;
        if(intersectionA != intersectionB && compararKeyRuta(intersectionA,intersectionB)){
            // Borrar la ruta
            String claveRuta = obtenerKeyRuta(intersectionA,intersectionB);
            Ruta ruta = rutas.get(claveRuta);
            ruta.makeInvisible();
            rutas.remove(claveRuta);
            // Borrar la sennal asociada a la ruta si existe
            String claveSennal = obtenerKeySennal(intersectionA,intersectionB);
            Sennal sennal = sennales.get(claveSennal);
            if(sennal != null){
                sennal.makeInvisible();
                sennales.remove(claveSennal);
            }
            this.ok = true;
        }
        else{
            System.out.println("La ruta no se puede borrar");
        }
    }

    /**
     * Metodo que borra una sennal.
     * @param IntersectionA Color de la interseccionA.
     * @param IntersectionB Color de la interseccionB.
     */
    public void removeSign(String intersectionA, String intersectionB){
        this.ok = false;
        if(intersectionA != intersectionB && compararKeySennal(intersectionA,intersectionB)){
            String claveSennal = obtenerKeySennal(intersectionA,intersectionB);
            Sennal sennal = sennales.get(claveSennal);
            sennal.makeInvisible();
            sennales.remove(claveSennal);
            this.ok = true;
        }
        else{
            System.out.println("La sennal no existe");
        }
    }

    /**
     * Metodo que perimte consultar las intercepciones.
     * @return String[] arreglo con las los colores de las intersecciones.
     */
    public String[] intersections(){
        this.ok = false;
        String[] intercepcionesColor = new String[intersecciones.size()];
        int cont = 0;
        for(String key:intersecciones.keySet()){
            intercepcionesColor[cont] = key;
            cont++;
        }
        this.ok = true;
        return intercepcionesColor;
    }
    
    /**
     * Metodo que perimte consultar las rutas.
     * @return String[][] matriz con las intersecciones en la que se encuentra la ruta.
     */
    public String[][] roads(){
        this.ok = false;
        String[][] rutasColor = new String[rutas.size()][1];
        int cont = 0;
        for(String key:rutas.keySet()){
            rutasColor[cont][0] = key;
            cont++;
        }
        this.ok = true;
        return rutasColor;
    }
    
    /**
     * Metodo que perimte consultar las sennales.
     * @return String[][] matriz con las intersecciones en la que se encuentra la sennal.
     */
    public String[][] signs(){
        this.ok = false;
        String[][] sennalesColor = new String[sennales.size()][1];
        int cont = 0;
        for(String key:rutas.keySet()){
            sennalesColor[cont][0] = key;
            cont++;
        }
        this.ok = true;
        return sennalesColor;
    }

    /**
     * Metodo que hace visible la red de ICPC.
     */
    public void makeVisible() {
        this.ok = false;
        this.isVisible = true;
        for (Interseccion value : intersecciones.values()) {
            if (value != null) {
                value.makeVisible();
            }
        }
        for (Ruta value : rutas.values()) {
            if (value != null) {
                value.makeVisible();
            }
        }
        for (Sennal value : sennales.values()) {
            if (value != null) {
                value.makeVisible();
            }
        }
        this.ok = true;
    }
    
    /**
     * Metodo que hace invisible la red de ICPC.
     */
    public void makeInvisible() {
        this.ok = false;
        this.isVisible = true;
        for (Interseccion value : intersecciones.values()) {
            if (value != null) {
                value.makeInvisible();
            }
        }
        for (Ruta value : rutas.values()) {
            if (value != null) {
                value.makeInvisible();
            }
        }
        for (Sennal value : sennales.values()) {
            if (value != null) {
                value.makeInvisible();
            }
        }
        this.ok = true;
    }
    
    /**
     * Metodo que finaliza el programa.
     */
    public void finish(){
        this.ok = false;
        System.exit(0);
        this.ok = true;
    }
    
    /**
     * Verifica la operacion indicada se pudo ejecutar en el simulador, este devolvera un mensaje de referencia.
     * @return true si la operacion se realizó satisfactoriamente,
     * de lo contrario false.
     */
    public boolean ok() {
        if (this.isVisible) {
            if (!this.ok) {
                System.out.println("La accion no se pudo realizar.");
            }
            else{
                 System.out.println("La accion se pudo realizar.");
            }
        }
        return this.ok;
    }

    /*
     * Verifica si dos posiciones de una interseccion ya existen.
     * @param int x, posicion x de la interseccion.
     * @param int y, posicion y de la interseccion.
     */
    private boolean verificarPosInterseccion(int x,int y){
        boolean verifica =  false;
        for (Interseccion value : intersecciones.values()) {
            int posX = value.getPositionx();
            int posY = value.getPositiony();
            if (value != null) {
                if(posX == x && posY == y){
                    verifica = true;
                }
            }
        }
        return verifica;
    }

    private ArrayList<String> verificarKeyRuta(String parteKey){
        ArrayList<String> claves = new ArrayList<String>();
        for(String key:rutas.keySet()){
            if (key.contains(parteKey)) {
                claves.add(key);
            }
        }
        return claves;
    }

    private ArrayList<String> verificarKeySennal(String parteKey){
        ArrayList<String> claves = new ArrayList<String>();
        for(String key:sennales.keySet()){
            if (key.contains(parteKey)) {
                claves.add(key);
            }
        }
        return claves;
    }

    /*
     * verifica que dos intersecciones no tengan una ruta
     * @param String intersectionA, color de la interseccion A
     * @param String intersectionB, color de la interseccion B
     */
    private boolean compararKeyRuta(String intersectionA, String intersectionB){
        String concatenacion1 = intersectionA+intersectionB;
        String concatenacion2 = intersectionB+intersectionA;
        boolean bandera = false;
        if(rutas.containsKey(concatenacion1) || rutas.containsKey(concatenacion2)){
            bandera = true;
        }
        return bandera;
    }

    /*
     * verifica que dos intersecciones no tengan una ruta
     * @param String intersectionA, color de la interseccion A
     * @param String intersectionB, color de la interseccion B
     */
    private boolean compararKeySennal(String intersectionA, String intersectionB){
        String concatenacion1 = intersectionA+intersectionB;
        String concatenacion2 = intersectionB+intersectionA;
        boolean bandera = false;
        if(sennales.containsKey(concatenacion1) || sennales.containsKey(concatenacion2)){
            bandera = true;
        }
        return bandera;
    }

    /*
     * Verifica si la key existe y si no da la que si existe
     * @param String intersectionA, color de la interseccion A
     * @param String intersectionB, color de la interseccion B
     */
    private String obtenerKeyRuta(String intersectionA, String intersectionB){
        String concatenacion1 = intersectionA+intersectionB;
        String concatenacion2 = intersectionB+intersectionA;
        String clave = null;
        if(rutas.containsKey(concatenacion1)){
            clave = concatenacion1;
        }
        if(rutas.containsKey(concatenacion2)){
            clave = concatenacion2;
        }
        return clave;
    }

    /*
     * Verifica si la key existe y si no da la que si existe
     * @param String intersectionA, color de la interseccion A
     * @param String intersectionB, color de la interseccion B
     */
    private String obtenerKeySennal(String intersectionA, String intersectionB){
        String concatenacion1 = intersectionA+intersectionB;
        String concatenacion2 = intersectionB+intersectionA;
        String clave = null;
        if(sennales.containsKey(concatenacion1)){
            clave = concatenacion1;
        }
        if(sennales.containsKey(concatenacion2)){
            clave = concatenacion2;
        }
        return clave;
    }
}
