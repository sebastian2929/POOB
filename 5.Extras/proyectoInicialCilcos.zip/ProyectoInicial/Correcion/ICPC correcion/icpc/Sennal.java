package icpc; 
import shapes.*;
import javax.swing.*;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Graphics;

/**
 * Write a description of class Sennal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sennal{
    private Triangle sennal;
    private JLabel etiqueta;
    /**
     * Constructor for objects of class Sennal
     */
    public Sennal(Interseccion interseccionA,Interseccion interseccionB,int SpeedLimit){
        this.sennal = new Triangle();
        int posXa = interseccionA.getPositionx();
        int posYa = interseccionA.getPositiony();
        int posXb = interseccionB.getPositionx();
        int posYb = interseccionB.getPositiony();
        int positionX = puntoMediox(posXa,posXb)+15;
        int positionY = puntoMedioy(posYa,posYb)-22;
        sennal.setPosition(positionX,positionY);
    }

    private int puntoMediox(int posXa,int posXb){
        int pMx = (posXa + posXb)/2;
        return pMx;
    }

    private int puntoMedioy(int posYa,int posYb){
        int pMy = (posYa + posYb)/2;
        return pMy;
    }

    public void makeVisible(){
        this.sennal.makeVisible();
    }

    public void makeInvisible(){
        this.sennal.makeInvisible();
    }

    public void paint(Graphics g,int velocidad,int x, int y){
        String speedL = String.valueOf(velocidad); 
        g.drawString(speedL,x,y);
    }
}
