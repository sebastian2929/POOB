package icpc; 
import shapes.*;

/**
 * Write a description of class Interseccion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Interseccion
{
    private Circle interseccion;

    /**
     * Constructor for objects of class Interseccion
     */
    public Interseccion(String color, int x, int y)
    {
        this.interseccion = new Circle();
        interseccion.changeColor(color);
        interseccion.moveHorizontal(x);
        interseccion.moveVertical(y);
    }
    
    public void makeVisible(){
        this.interseccion.makeVisible();
    }
    
    public void makeInvisible(){
        this.interseccion.makeInvisible();
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        this.interseccion.changeColor(newColor);
    }
    
    /**
     * Move the intersection horizontally.
     * @param distance the desired distance in pixels
     */
    public void moveHorizontal(int distance){
        this.interseccion.moveHorizontal(distance);
    }

    /**
     * Move the intersection vertically.
     * @param distance the desired distance in pixels
     */
    public void moveVertical(int distance){
        this.interseccion.moveVertical(distance);
    }
    
    /**
     * Get the color of the intersection
     */
    public String getColor(){
        return this.interseccion.getColor();
    }
    
    /**
    *Get the xPosition of the intersction
    */
    public int getPositionx(){
        return this.interseccion.getPositionx();
    }
    
    /**
    *Get the yPosition of the intersection
    */
    public int getPositiony(){
        return this.interseccion.getPositiony();
    }
}
