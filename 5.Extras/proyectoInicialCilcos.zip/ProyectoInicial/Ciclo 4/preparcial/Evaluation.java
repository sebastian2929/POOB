import java.time.LocalDate;

public class Evaluation {

	private LocalDate date;

	private int percentage;

	private Inscription inscription;

}
