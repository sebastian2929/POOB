public class HumanEvaluator extends Evaluator {

}
