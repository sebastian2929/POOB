import java.util.Collection;

public class AutomaticEvaluator extends Evaluator {

	private Collection<UnitTest> unitTests;

}
