import java.util.Collection;

public class SwFactory {

    private String[] clients;

    private Collection<Team> teams;

    private Collection<Project> projects;

    private Collection<Inscription> inscriptions;

    private Collection<Certificates> certificates;

    private Collection<Feedbacker> feedbackers;
    
    public Team foundTeamWinner(String idProject){
        try{
            Proyect proyect = loadProjectByid(idProyect);
            inscriptions = loadInscriptionByProject(project);
            for(Incription i : inscriptions){
                try{
                    int percentage = evaluateIncripcion();
                }
                catch(swFactoryException e){
                    e.getMensaje(PROJECT_HAS_WINNER);                
                }
            }
        }
        catch(swFactoryException e){
            printStackTrace();
        }
    }
}
