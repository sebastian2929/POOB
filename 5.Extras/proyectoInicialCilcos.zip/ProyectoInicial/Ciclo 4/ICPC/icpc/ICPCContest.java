package icpc;
import shapes.*;
/**
 * Write a description of class ICPCContest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ICPCContest
{
    boolean ok = false;
    ICPC icpc;

    /**
     * Metodo que da solucion al problema de la red de ICPC.
     * @param int cost, Costo de poner una sennal.
     * @param int[][] routesSpeedLimist, Matriz con la red ICPC.
     */
    public int solve(int cost, int routeSpeedLimits[][]){
        int totalCost = 0;
        int maxSpeedLimit = routeSpeedLimits[0][2];
        if(cost >= 100){
            for(int i = 1; i < routeSpeedLimits.length;i++){
                if(routeSpeedLimits[i][2] > maxSpeedLimit){
                    maxSpeedLimit = routeSpeedLimits[i][2];
                    System.out.println("max" + maxSpeedLimit);
                }
            }
            for(int i = 0; i < routeSpeedLimits.length;i++){
                totalCost += (maxSpeedLimit - routeSpeedLimits[i][2]);
            }
            matrizIcpcCm(cost,maxSpeedLimit,routeSpeedLimits);
        }
        else if(cost > 0 && cost < 100 ){
            int[][] redIcpc= new int[routeSpeedLimits.length][4];
            for(int i = 1; i < routeSpeedLimits.length;i++){
                if(routeSpeedLimits[i][2] > maxSpeedLimit){
                    maxSpeedLimit = routeSpeedLimits[i][2];
                    System.out.println("max" + maxSpeedLimit);
                }
            }
            for(int i = 0; i < routeSpeedLimits.length;i++){
                int diferencia = maxSpeedLimit - routeSpeedLimits[i][2];
                redIcpc[i][0] = routeSpeedLimits[i][0];
                redIcpc[i][1] = routeSpeedLimits[i][1];
                if(diferencia > cost || diferencia == 0){
                    totalCost += cost;
                    redIcpc[i][2] = routeSpeedLimits[i][2];
                    redIcpc[i][3] = 1;
                }
                else{
                    totalCost += diferencia;
                    redIcpc[i][2] = maxSpeedLimit;
                    redIcpc[i][3] = 0;
                }
            }
            simulate(cost,redIcpc);
        }
        return totalCost;
    }

    /**
     * Metodo que simula la construccion de una red ICPC
     * @param int cost, Costo de poner una sennal.
     * @param int[][] routesSpeedLimist, Matriz con la red ICPC.
     */
    public void simulate(int cost, int routeSpeedLimits[][]){
        this.icpc = new ICPC(cost,routeSpeedLimits);
        this.icpc.makeVisible();
        ok = true;
    }

    /**
     * Metodo que verifica la operacion indicada se pudo ejecutar en el simulador, este devolvera un mensaje de referencia.
     * @return boolean, true si la operacion se realizó satisfactoriamente, de lo contrario false.
     */
    public boolean ok(){
        if (this.icpc.isVisible) {
            if (!this.ok) {
                System.out.println("La accion no se pudo realizar.");
            }
            else{
                System.out.println("La accion se pudo realizar.");
            }
        }
        return ok;
    }

    /*
     * Metodo que genera la matriz de la red icpc cuando el costo es muy elevado.
     * int valorMaximo, limite de velocidad maximo.
     */
    private void matrizIcpcCm(int cost,int valorMaximo , int matriz[][]){
        int m[][] = new int[matriz.length][4];
        for(int i = 0; i< matriz.length;i++){
            m[i][0]= matriz[i][0];
            m[i][1]= matriz[i][1];
            m[i][2]= valorMaximo;
            m[i][3]= 0;
        }
        simulate(cost,m);
    }
}
