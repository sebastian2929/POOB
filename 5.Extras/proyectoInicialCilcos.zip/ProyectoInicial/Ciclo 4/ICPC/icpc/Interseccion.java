package icpc;
import shapes.*;
import java.util.ArrayList;

/**
 * Write a description of class Interseccion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Interseccion
{
    private Circle interseccion;
    private ArrayList<Ruta> interseccionRutas = new ArrayList<Ruta>();

    /**
     * Constructor de los objetos la clase Interseccion.
     * @param String color, Color de la interseccion.
     * @param int x, Posicion x de la interseccion.
     * @param int y, Posicion y de la interseccion.
     */
    public Interseccion(String color, int x, int y)
    {
        this.interseccion = new Circle();
        interseccion.changeColor(color);
        interseccion.moveHorizontal(x);
        interseccion.moveVertical(y);
    }
    
    /**
     * Metodo que hace visible la ruta.
     */
    public void makeVisible(){
        this.interseccion.makeVisible();
    }
    
    /**
     * Metodo que hace invisible la ruta.
     */
    public void makeInvisible(){
        this.interseccion.makeInvisible();
    }
    
    /**
    * Metodo que obtiene la posicion x de la inteterseccion.
    * @return posicionX, PosicionX de la interseccion.
    */
    public int getPositionx(){
        return this.interseccion.getPositionx();
    }
    
    /**
    * Metodo que obtiene la posicion y de la inteterseccion.
    * @return posicionY, PosicionY de la interseccion.
    */
    public int getPositiony(){
        return this.interseccion.getPositiony();
    }
    
    /**
     * Metodo que verifica que la interseccion este relacionada con la ruta
     */
    public void verificaRuta(Ruta ruta){
        if(!interseccionRutas.contains(ruta)){
           interseccionRutas.add(ruta);
        }
    }
    
    /**
     * Metodo que obtiene el ArrayList de rutas de cada interseccion.
     * @return ArrayList<Ruta> rutas, rutas de la interseccion.
     */
    public ArrayList<Ruta> getRutas(){
        return interseccionRutas;
    }
    
    /**
     * Metodo que modifica el arraylist de rutas de una interseccion;
     * @param ArrrayList<Ruta> rutas , rutas de la interseccion;
     */
    public void setRutas(ArrayList<Ruta> rutas){
        interseccionRutas = rutas;
    }
    
    /**
     * Metodo que borra una ruta del ArrayList de rutas de una interseccion.
     */
    public void removeRuta(Ruta ruta){
        interseccionRutas.remove(ruta);
    }
}
