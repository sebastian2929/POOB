import javax.swing.JLabel;

/**
 * Write a description of class Sennal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sennal
{
    private Triangle sennal;
    private JLabel etiqueta;
    
    /**
     * Constructor for objects of class Ruta
     */
    public Sennal() {
        this.sennal = new Triangle();
        etiqueta = new JLabel();
        
    }

    public void makeVisible(){
        this.sennal.makeVisible();
    }
    
    public void makeInvisible(){
        this.sennal.makeInvisible();
    }
}
