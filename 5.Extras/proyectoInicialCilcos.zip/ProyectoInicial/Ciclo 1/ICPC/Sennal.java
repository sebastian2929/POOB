
/**
 * Write a description of class Sennal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sennal
{
    private Triangle sennal;
    
    /**
     * Constructor for objects of class Ruta
     */
    public Sennal() {
        this.sennal = new Triangle();
    }

    public void makeVisible(){
        this.sennal.makeVisible();
    }
    
    public void makeInvisible(){
        this.sennal.makeInvisible();
    }
}
