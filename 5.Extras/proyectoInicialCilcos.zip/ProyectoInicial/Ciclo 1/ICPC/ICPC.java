import java.util.*;
/**
 * Crea un red ICPC donde se pueden agregar y modificar intercepciones, rutas y sennales.
 * 
 * @Andres Felipe Arias Ajiaco y Sebastian David Blanco Rodriguez. 
 * @version 1.3.
 */


public class ICPC {
    private ArrayList<Interseccion> intersections = new ArrayList<Interseccion>();
    private ArrayList<Ruta> routes = new ArrayList<Ruta>();
    private ArrayList<Sennal> signs  = new ArrayList<Sennal>();
    private int length;
    private int width;
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int length, int width) {
      Canvas board = Canvas.getCanvas("ICPC",width,length);
      board.redraw1();
    }
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int length, int width, int cost) {
        
       
    }
    
    /**
     * Constructor de la red ICPC.
     * @param length Longitud de la matriz.
     * @param width Ancho de la matriz.
     */
    public ICPC(int cost, int[][] routesSpeedLimits) {
        
       
    }
    
    /**
     * Metodo que annade una interseccion a la red ICPC.
     * @param color Cadena con el color de la inteseccion.
     * @param x Entero con la posicion en x de la interseccion.
     * @param y Entero con la posicion en y de la interseccion.
     */
    public void addInteserction(String color, int x, int y) {
        Interseccion intersection = new Interseccion();
        intersection.changeColor(color);
        intersection.moveHorizontal(x*10);
        intersection.moveVertical(y*10);
        if (this.isVisible) {
            intersection.makeVisible();
        }
        intersections.add(intersection); 
    }
    
    /**
     * Metodo que annade una ruta a la red ICPC.
     * @param intersectionA Color con la interseccion A.
     * @param intersectionB Color con la interseccion B.
     */
    public void addRoute(String intersectionA, String intersectionB) {
        boolean bandera1 = false;
        boolean bandera2 = false;
        Interseccion interseccionA = null;
        Interseccion interseccionB = null;
        for (int i=0;i<intersections.size();i++) {
            Interseccion intersec = intersections.get(i);
            if (intersec!= null){
                if (intersec.getColor().equals(intersectionA)){
                    interseccionA = intersections.get(i);
                    bandera1 = true;
                }
                if(intersec.getColor().equals(intersectionB)){
                    interseccionB = intersections.get(i); 
                    bandera2 = true;
                }
            }
        }
        if(bandera1 && bandera2){
            setRoute(interseccionA,interseccionB);
        }
        else{
            System.out.println("No es posible");
        }
    }
    
    /**
     * set the route
     * @param interseccion A
     * @param interseccion B
     */
    private void setRoute(Interseccion interseccionA, Interseccion interseccionB){
        int posAx = interseccionA.getPositionx();
        int posAy = interseccionA.getPositiony();
        int posBx = interseccionB.getPositionx();
        int posBy = interseccionB.getPositiony();
        int numerador = posBy-posAy;
        int denominador = posBx-posAx;
        int distancia = getDistance(denominador,numerador);
        int angulo = getAngle(posAx,posAy,posBx,posBy);
        Ruta route = new Ruta();
        route.changeColor("green");
        int mayorX = posAx > posBx ? posBx : posAx;
        int mayorY = 0;
        if(posAx == posBx && posAy > posBy){
            mayorY = posAy;
        }
        if(posAx == posBx && posAy < posBy){
            mayorY = posBy;
        }
        else{
            mayorY = mayorX == posAx ? posAy : posBy;
        }
        route.changePosition((mayorX + 15), (mayorY - 22));
        route.changeSize(10,distancia);
        route.changeAngle(angulo);
        routes.add(route);
        if (this.isVisible){
            route.makeVisible();
        } else{
            System.out.println("No es posible");
        }
    }
    
    /***
     * Delete a route
     * @param location A
     * @param location B
     */
    public void delRoad(String locationA, String locationB){
        Interseccion interseccionA = null;
        Interseccion interseccionB = null;
        for (int i=0;i<intersections.size();i++) {
            Interseccion intersec = intersections.get(i);
            if (intersec!= null){
                if (intersec.getColor().equals(locationA)){
                    interseccionA = intersections.get(i);
                }
                if(intersec.getColor().equals(locationB)){
                    interseccionB = intersections.get(i); 
                }
            }
        }
        int posAx = interseccionA.getPositionx();
        int posAy = interseccionA.getPositiony();
        int posBx = interseccionB.getPositionx();
        int posBy = interseccionB.getPositiony();
        int angle = getAngle(posAx,posAy,posBx,posBy);
        boolean bandera = false;
        for(int i = 0; i<routes.size();i++){
            Ruta ruta = routes.get(i);
            if(ruta!=null){
                int angulo = ruta.getAngle();
                if(angulo == angle){
                    bandera = true;
                    ruta.makeInvisible();
                    routes.remove(i);
                }
            }
        }
        if(bandera == false){
            System.out.println("No esxite");
        }
    }
    
    /***
     * Get the distance between two points
     * @param point1
     * @param point2
     * @return ditancet
     */
    private int getDistance(int point1, int point2){
        int distance;
        distance = (int)(Math.sqrt(Math.pow((point1),2) + Math.pow((point2),2)));
        return distance;
    }
    
    /***
     * Get the slope between two points
     * @param posAx 
     * @param posAy
     * @param posBx
     * @param posBy
     * @return slope
     */
    private double getSlope(int posAx,int posAy , int posBx, int posBy){
        double numerador;
        double denominador;
        double pendiente;
        numerador = (posBy - posAy);
        denominador =(posBx - posAx);
        pendiente = numerador / denominador;
        return pendiente * -1;
    }
    
    /***
     * Get the Angle between two points
     * @param 
     * @param 
     * @param posAx position of an intersectionA in x
     * @param posbx position of an intersectionB in x
     * @return angle
     */
    private int getAngle(int posAx,int posAy, int posBx, int posBy){
        int angle;
        double pendiente = getSlope(posAx,posAy,posBx,posBy);
        if((posBx - posAx)== 0 ){
            angle = posAx < posBx ? 270 : 90;
        }
        else{
        angle = (int)(Math.toDegrees(Math.atan(pendiente)));
        }
        return angle;
    }
    
    /**
     * Metodo que borrra una intercepcion de la red de ICPC.
     * @param color color de la intrecepcion.
     */
    public void delIntersection(String color){
        boolean bandera = false;
        for(int i = 0; i < intersections.size(); i++){
            Interseccion intersec = intersections.get(i);
            if(intersec != null){
                if(intersec.getColor().equals(color)){
                    bandera = true;
                    intersec.makeInvisible();
                    intersections.remove(i);
                }
            }
        }
        if(bandera = false){
            System.out.println("No es posible");
        }
    }
    
    /***
     * Metodo que perimte consultar las intercepciones.
     */
    public String[] intersections(){
        int cont = 0;
        String[] intercepciones = new String[intersections.size()];
        String color;
        for(int i = 0; i < intersections.size(); i++){
            Interseccion intersec = intersections.get(i);
            if(intersec != null){
                color = intersec.getColor();
                intercepciones[cont] = color;
                cont++;
            }
        }
        return intercepciones;
    }
    
    /**
     * Metodo que hace visible la red de ICPC.
     */
    public void makeVisible() {
        this.isVisible = true;
        for (Interseccion intersection : intersections) {
            if (intersection != null) {
                intersection.makeVisible();
            }
        }
        for (Ruta route : routes) {
            if (route != null) {
                route.makeVisible();
            }
        }
    }
    
    /**
     * Metodo que hace invisible la red de ICPC.
     */
    public void makeInvisible() {
        this.isVisible = false;
        for (Interseccion intersection : intersections) {
            if (intersection != null) {
                intersection.makeInvisible();
            }
        }
        for (Ruta route : routes) {
            if (route != null) {
                route.makeVisible();
            }
        }
    }
}
