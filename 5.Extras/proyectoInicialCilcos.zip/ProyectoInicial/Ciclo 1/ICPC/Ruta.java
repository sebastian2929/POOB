/**
 * Write a description of class Ruta here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ruta {
    // instance variables - replace the example below with your own
    private Rectangle ruta;

    /**
     * Constructor for objects of class Ruta
     */
    public Ruta() {
        this.ruta = new Rectangle();
    }

    public void makeVisible(){
        this.ruta.makeVisible();
    }
    
    public void makeInvisible(){
        this.ruta.makeInvisible();
    }
    
    public void changeAngle(int newAngle) {
        this.ruta.setAngle(newAngle);
    }
    
    public void changePosition(int newPositionx, int newPositiony){
        this.ruta.setPosition(newPositionx,newPositiony);
    }
    
    public int getAngle() {
        return this.ruta.getAngle();
    }
    
    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidth must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        this.ruta.changeSize(newHeight, newWidth);
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        this.ruta.changeColor(newColor);
    }
}
