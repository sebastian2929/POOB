public class Tramo {

}
