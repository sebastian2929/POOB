import java.util.ArrayList;
import java.util.HashMap;

public class Ruta {
    private ArrayList<String> parada = new ArrayList<String>();
    private HashMap<String, Estacion> paradas = new HashMap<String, Estacion>();

    public int numeroParadas(String nombre1, String nombre2){
        ArrayList<Estacion> contar = new ArrayList<Estacion>();
        Estacion estacion1 = paradas.get(nombre1); 
        Estacion estacion2 = paradas.get(nombre2);
        for(Estacion estacionInicio: paradas.values()){
            if(estacion1 == estacionInicio){
                contar.add(estacionInicio);




        for(Estacion estacionFin: paradas.values()){
            if(){

            }
            }

        }
    }

    public int numeroParada(String nombre1, String nombre2){
        for(int i =0; i < parada.length() ; i++){
            if(parada[i].equals(nombre1)){

            }
                contar.add(estacionInicio);




        for(Estacion estacionFin: paradas.values()){
            if(){

            }
            }

        }
    }
}
