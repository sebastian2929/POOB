import java.util.HashMap;

public class Transmilenio {

    private HashMap<String, Estacion> estaciones = new HashMap<String, Estacion>();

    public int tiempoEspera(String nombre) {
        Estacion estacion = estaciones.get(nombre);
        int tiempo = estacion.getTiempoEspera();
        return tiempo;
    }

    public int numParadas(String nombreRuta, String nombre1, String nombre2) {
        Estacion estacion1 = estaciones.get(nombre1);
        Ruta ruta = estacion1.getRuta(nombreRuta);

        Estacion estacion2 = estaciones.get(nombre2);

    }
}