public class Troncal {

}
